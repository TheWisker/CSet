mkdir -v ./bin
meson setup bin