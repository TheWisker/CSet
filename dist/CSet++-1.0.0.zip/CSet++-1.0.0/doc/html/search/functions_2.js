var searchData=
[
  ['diff_0',['diff',['../namespaceset.html#a37f2c9c18fda658d3fb86550e519e773',1,'set::diff(std::vector&lt; T &gt; &amp;c, const std::vector&lt; T &gt; &amp;k, const std::vector&lt; T &gt; &amp;kk)'],['../namespaceset.html#adab78d19090efa67608f5bdf7edfcd17',1,'set::diff(const std::vector&lt; T &gt; &amp;k, const std::vector&lt; T &gt; &amp;kk)'],['../namespaceset.html#a33807611580dac21eeb1d4629635d571',1,'set::diff(std::vector&lt; T &gt; &amp;&amp;k, const std::vector&lt; T &gt; &amp;&amp;kk)']]]
];
