var searchData=
[
  ['set_0',['set',['../namespaceset.html',1,'']]]
];
