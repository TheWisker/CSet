var searchData=
[
  ['intersection_0',['intersection',['../namespaceset.html#abbfdb13d235a0b18b76350266fe35645',1,'set::intersection(std::vector&lt; T &gt; &amp;c, const std::vector&lt; T &gt; &amp;k, const std::vector&lt; T &gt; &amp;kk)'],['../namespaceset.html#a937da7a049b9728f41cdd28143fc8aab',1,'set::intersection(const std::vector&lt; T &gt; &amp;k, const std::vector&lt; T &gt; &amp;kk)'],['../namespaceset.html#a9bf96dd651d61262a4aacebd188f6677',1,'set::intersection(std::vector&lt; T &gt; &amp;&amp;k, const std::vector&lt; T &gt; &amp;&amp;kk)']]]
];
