var searchData=
[
  ['sdiff_0',['sdiff',['../namespaceset.html#a9e1d205dc88719374276b5bd73fc13b6',1,'set::sdiff(std::vector&lt; T &gt; &amp;c, const std::vector&lt; T &gt; &amp;k, const std::vector&lt; T &gt; &amp;kk)'],['../namespaceset.html#aadf61b4b009c85eedfebcd324744433b',1,'set::sdiff(const std::vector&lt; T &gt; &amp;k, const std::vector&lt; T &gt; &amp;kk)'],['../namespaceset.html#a2ef17eb00844ef043ce1ddeba457037c',1,'set::sdiff(std::vector&lt; T &gt; &amp;&amp;k, const std::vector&lt; T &gt; &amp;&amp;kk)']]],
  ['set_1',['set',['../namespaceset.html',1,'']]],
  ['set_2ecpp_2',['set.cpp',['../benchmark_2set_8cpp.html',1,'(Global Namespace)'],['../test_2set_8cpp.html',1,'(Global Namespace)']]],
  ['set_2eh_3',['set.h',['../set_8h.html',1,'']]],
  ['sort_4',['sort',['../namespaceset.html#acd71ed889f217fdd2ed230a7af7239b0',1,'set::sort(std::vector&lt; T &gt; &amp;c, const std::vector&lt; T &gt; &amp;k)'],['../namespaceset.html#ab56c2eb27a6ca1608fcaca498bb469c1',1,'set::sort(std::vector&lt; T &gt; &amp;k)'],['../namespaceset.html#aa471bbd83d3f4218c46fbdd911036003',1,'set::sort(std::vector&lt; T &gt; &amp;&amp;k)']]],
  ['sunion_5',['sunion',['../namespaceset.html#ad0fdcd2362fa264e9d23cba85ccec05c',1,'set::sunion(std::vector&lt; T &gt; &amp;c, const std::vector&lt; T &gt; &amp;k, const std::vector&lt; T &gt; &amp;kk)'],['../namespaceset.html#a4ed87ed055788fd8d140f6a319a40c52',1,'set::sunion(const std::vector&lt; T &gt; &amp;k, const std::vector&lt; T &gt; &amp;kk)'],['../namespaceset.html#a0e3e720e169b3cbea702da06e7241494',1,'set::sunion(std::vector&lt; T &gt; &amp;&amp;k, const std::vector&lt; T &gt; &amp;&amp;kk)']]]
];
