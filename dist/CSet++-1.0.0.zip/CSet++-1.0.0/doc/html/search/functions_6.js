var searchData=
[
  ['sdiff_0',['sdiff',['../namespaceset.html#a9e1d205dc88719374276b5bd73fc13b6',1,'set']]],
  ['sunion_1',['sunion',['../namespaceset.html#ad0fdcd2362fa264e9d23cba85ccec05c',1,'set']]]
];
