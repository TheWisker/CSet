var searchData=
[
  ['reverse_0',['reverse',['../namespaceset.html#acea3595093efb07e1bc491fd2d9ed303',1,'set::reverse(std::vector&lt; T &gt; &amp;c, const std::vector&lt; T &gt; &amp;k)'],['../namespaceset.html#ab913282f766e96ea5e334f25c7ce1c8e',1,'set::reverse(std::vector&lt; T &gt; &amp;k)'],['../namespaceset.html#a378e8ea58f8e5746692d9c911b36968c',1,'set::reverse(std::vector&lt; T &gt; &amp;&amp;k)']]],
  ['rsort_1',['rsort',['../namespaceset.html#ac064d67f787dd20fcfbd46cbf4e7717c',1,'set::rsort(std::vector&lt; T &gt; &amp;c, const std::vector&lt; T &gt; &amp;k)'],['../namespaceset.html#a36984d54610ebb1926243864141934c7',1,'set::rsort(std::vector&lt; T &gt; &amp;k)'],['../namespaceset.html#af76b38d3248072064d37e0abfb6d99de',1,'set::rsort(std::vector&lt; T &gt; &amp;&amp;k)']]]
];
