<h1 align="center">C++ Set Theory Library</h1>
<p align="center">Library for set theory operation on std::vector</p>

<h2 align="center">Introdution</h2>

This is a simple project that aims to provide some simple and fast methods for working with mathematical sets on std::vectors.
At the moment it only includes a handful of functions in the set namespace. The library may be expanded at a future time depending on my needs.

<h2 align="center">Documentation</h2>

<p align="center">https://thewisker.github.io/CSet</p>

<h2 align="center">Author</h2>
<div align="center">
    <img width="200" height="200" src="assets/profile.png"></img>
</div>
<h4 align="center">TheWisker</h4>